#ifndef _POSIF1_H_
#define _POSIF1_H_


#include <xmc_posif.h>
#include <xmc_gpio.h>

void POSIF1_Init(void);


#endif
