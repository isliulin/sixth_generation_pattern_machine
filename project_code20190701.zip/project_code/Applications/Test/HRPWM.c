//XMC Lib Project includes:
#include "HRPWM.h"

void HRPWM_Init(void)
{
  
  
  
}


void HRPWM_0_IRQn(void)
{
  
  
}
void HRPWM_1_IRQn(void)
{
  
  
}
void HRPWM_2_IRQn(void)
{
  
  
}
void HRPWM_3_IRQn(void)
{
  
  
}