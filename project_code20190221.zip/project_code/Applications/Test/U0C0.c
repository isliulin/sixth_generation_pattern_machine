//XMC Lib Project includes:
#include "U0C0.h"




//UART



//SPI



//IIC

