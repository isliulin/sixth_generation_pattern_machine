#ifndef _CCU40_H_
#define _CCU40_H_

#include <xmc_ccu4.h>
#include <xmc_gpio.h>
#include <xmc_scu.h>

void CCU40_Init(void);

#endif
