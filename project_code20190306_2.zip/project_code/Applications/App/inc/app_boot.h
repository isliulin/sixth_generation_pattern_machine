#ifndef APP_BOOT_H
#define APP_BOOT_H


/*----------------------------------------------------------------------------*/
void app_BootInit(void);
void app_BootLoop(void);



#endif /* APP_BOOT_H */