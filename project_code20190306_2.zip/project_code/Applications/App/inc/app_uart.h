#ifndef APP_UART_H
#define APP_UART_H



/*----------------------------------------------------------------------------*/
void app_UartInit(void);


















#endif /* APP_UART_H */

