#ifndef APP_ADC_H
#define APP_ADC_H



//analog
/*----------------------------------------------------------------------------*/
void app_AdcInit(void);
void app_AdcGetValue(uint8_t channel, uint16_t value);



#endif /* APP_ADC_H */