#ifndef _CCU42_H_
#define _CCU42_H_

#include <xmc_ccu4.h>
#include <xmc_gpio.h>
#include <xmc_scu.h>

void CCU42_Init(void);

#endif
