//XMC Lib Project includes:
#include "CCU43.h"

void CCU43_Init(void)
{
  
}
void CCU43_DeInit(void)
{
  
}