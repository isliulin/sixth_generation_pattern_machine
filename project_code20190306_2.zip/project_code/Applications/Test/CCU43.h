#ifndef _CCU43_H_
#define _CCU43_H_

#include <xmc_ccu4.h>
#include <xmc_gpio.h>
#include <xmc_scu.h>

void CCU43_Init(void);

#endif
