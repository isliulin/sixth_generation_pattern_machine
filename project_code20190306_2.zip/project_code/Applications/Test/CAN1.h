#ifndef _CAN1_H_
#define _CAN1_H_



//#include <XMC4500.h>
#include "xmc_can.h"




#endif