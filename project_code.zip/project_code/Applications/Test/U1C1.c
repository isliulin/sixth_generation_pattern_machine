//XMC Lib Project includes:
#include "U1C1.h"