#ifndef APP_SOFTWARE_H
#define APP_SOFTWARE_H




/*----------------------------------------------------------------------------*/
void app_SoftwareInit(void);












#endif /* APP_SOFTWARE_H */

