#ifndef _CAN0_H_
#define _CAN0_H_

//#include <XMC4500.h>
#include "xmc_can.h"

#endif