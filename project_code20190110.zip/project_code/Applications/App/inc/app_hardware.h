#ifndef APP_HARDWARE_H
#define APP_HARDWARE_H



#define TICKS_PER_SECOND        1000







void app_HardwareInit(void);











#endif /* APP_HARDWARE_H */

