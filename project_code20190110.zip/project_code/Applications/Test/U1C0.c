//XMC Lib Project includes:
#include "U1C0.h"