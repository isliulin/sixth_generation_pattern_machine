#ifndef _CCU41_H_
#define _CCU41_H_

#include <xmc_ccu4.h>
#include <xmc_gpio.h>
#include <xmc_scu.h>

void CCU41_Init(void);

#endif
