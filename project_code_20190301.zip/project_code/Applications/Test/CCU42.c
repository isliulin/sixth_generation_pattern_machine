//XMC Lib Project includes:
#include "CCU42.h"

void CCU42_Init(void)
{
  
}
void CCU42_DeInit(void)
{
  
}