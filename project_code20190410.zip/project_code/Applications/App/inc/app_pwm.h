#ifndef APP_PWM_H
#define APP_PWM_H





/*----------------------------------------------------------------------------*/
void app_PwmInit(void);
void app_PwmSetValue(uint8_t channel, uint16_t value);










#endif /* APP_PWM_H */

