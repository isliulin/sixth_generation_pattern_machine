//XMC Lib Project includes:
#include "U0C1.h"