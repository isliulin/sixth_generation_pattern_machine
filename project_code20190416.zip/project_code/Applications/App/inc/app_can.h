#ifndef APP_CAN_H
#define APP_CAN_H

#include "can_node.h"

void app_Can_Init(void);





#endif /* APP_CAN_H */
