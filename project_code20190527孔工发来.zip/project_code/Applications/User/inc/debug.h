#ifndef DEBUG_H
#define DEBUG_H

extern void debug_mode_init(void);

#endif
