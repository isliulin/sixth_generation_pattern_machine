#ifndef _POSIF0_H_
#define _POSIF0_H_


#include <xmc_posif.h>
#include <xmc_gpio.h>

void POSIF_Init(void);


#endif
